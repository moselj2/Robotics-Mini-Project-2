addpath(genpath(pwd))
close all;

rw=0.2; rz=0.1;
robot=collisionCylinder(rw, rz);
colobj = roomspec();

roomshow(colobj, 1);
axis('square');

%path found by running PRM_path, RRT_path beforehand
if length(path)==1 %RRT Path
    path=path.States(:,1:2);
end
if length(path>1) %PRM Path
    while length(path)<20
        i=1;
        tmp=[];
        while i<length(path)
            tmpA=path(i,:);
            tmpB=(path(i+1,:)-path(i,:))*0.5+path(i,:);
            tmp=[tmp; tmpA; tmpB];
            i=i+1;
        end
        path=tmp;
    end
end
roomshow(colobj, 1);
axis('square');
hold on; plot(path(:,1),path(:,2),'o');
N_step=length(path)-1;
q0=[path(1,:)';0];
clear q;
q(:,1)=q0;

ez=[0;0;1];
% # of scan lines in lidar
N_scan=8; 
% **** range sensors ****
% UWB (local GPS)
zW=colobj.obj{1}.Z;
lW=colobj.obj{1}.X;
zW=0;
pL(:,1)=[0;0;zW];pL(:,2)=[lW;0;zW]; % Only use 2 range sensors 
% **** bearing sensors ****
pB(:,1)=colobj.obj{14}.Pose(1:3,4);
pB(:,2)=colobj.obj{10}.Pose(1:3,4);
N_range=size(pL,2);N_bearing=size(pB,2);N_odo=2;
ns=N_range+N_bearing+N_odo+N_scan; % total # of sensors

%wcov=[0.001;0.001];vcov=.1*ones(ns,1); % noise covariance
wcov=[0;0];vcov=0*ones(ns,1); % noise covariance

% steering command and sampling period
v=.1;w=.1;ts=1;
% initial sensor reading
y(:,1)=output(q(:,1),pL,pB,N_scan,[0;0],vcov,robot,colobj);
% initial state estimate
qhat(:,1)=pose_est(y(:,1),pL,pB,N_scan,wcov,vcov);

% initialization for the EKF
qhat_EKF(:,1)=qhat(:,1);P{1}=.1*eye(3,3);S{1}=.1*eye(3,3);

%N_step=length(path)*2;


rho0=0.2;
index=[];
for i=1:N_step
    index=[index i i];
end

%% 

for k=1:N_step*2
%for k=1:25
    if rem(k,2)==1 %odd turns, turn
        [isInt,dist,wp]=colcheck(robot,q(:,k),colobj);
        [rho,loc]=min(dist);
        dq=path(index(k)+1,:)'-q(1:2,k);
        rep=(rho<rho0)*(0.01/rho^2)*(wp{loc}(1:2,1)-wp{loc}(1:2,2));
        deltaq=dq+rep;
        u1=0;
        u2=-q(3,k)+atan(deltaq(2)/deltaq(1));
        u2=u2;
    else %even turns, move
        [isInt,dist,wp]=colcheck(robot,q(:,k),colobj);
        [rho,loc]=min(dist);
        dq=path(index(k)+1,:)'-q(1:2,k);
        rep=(rho<rho0)*(0.01/rho^2)*(wp{loc}(1:2,1)-wp{loc}(1:2,2));
        deltaq=dq+rep;
        u1=norm(deltaq);
        if u1>0.3
            u1=0.3;
        end
        u2=0;
    end
    q(:,k+1)=q(:,k)+[cos(q(3,k)) 0;sin(q(3,k)) 0;0 1]*[u1;u2];
    % check collision 
    [isInt,dist,wp]=colcheck(robot,q(:,k+1),colobj);   
    if max(isnan(dist))>0
        q(:,k+1)=q(:,k);disp('collision!');
    end
    robotshow(robot,q(:,k+1));
    xlabel('X [meters]'); ylabel('Y [meters]');
    pause(0.1);
    k=k+1
end