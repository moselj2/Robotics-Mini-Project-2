addpath(genpath(pwd))

%addpath ../lidar_demo

rw=0.2; rz=0.1;

robot=collisionCylinder(rw, rz);

colobj = roomspec();

resolution = 100;
binary_map = color2binary(colobj, resolution);

%show(binary_map);
%view(-90,90);

free_space=binary_map;
inflate(free_space,0.2);
show(free_space); view(-90,90);

q0=[.55;2;0];

i=0;
while i==0
    qf=[10*rand(2,1) ;0]
    if checkOccupancy(free_space,qf(1:2)')==0
        i=1;
    end
end
qf=[9;6;0]


ss=stateSpaceSE2;
sv=validatorOccupancyMap(ss);
sv.Map=free_space;
sv.ValidationDistance=0.01;
ss.StateBounds=[free_space.XWorldLimits; free_space.YWorldLimits; [-pi pi]];
planner=plannerRRT(ss,sv);
planner.MaxConnectionDistance=0.3;
[path,solnInfo]=plan(planner,q0',qf');

figure(1); hold on
plot(solnInfo.TreeData(:,1), solnInfo.TreeData(:,2),'.-');

plot(path.States(:,1), path.States(:,2),'r-','Linewidth',2)

