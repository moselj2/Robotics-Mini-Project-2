addpath(genpath(pwd))

%addpath ../lidar_demo

rw=0.2; rz=0.1;

robot=collisionCylinder(rw, rz);

colobj = roomspec();

resolution = 100;
binary_map = color2binary(colobj, resolution);

%show(binary_map);
%view(-90,90);

free_space=binary_map;
inflate(free_space,0.2);
show(free_space); view(-90,90);

q0=[.4;2;0];

%i=0;
%while i==0
%    qf=[10*rand(2,1) ;0]
%    if checkOccupancy(free_space,qf(1:2)')==0
%        i=1;
%    end
%end
%qf=[9;6;0]

ss=stateSpaceSE2;
sv=validatorOccupancyMap(ss);
sv.Map=free_space;
sv.ValidationDistance=0.01;
ss.StateBounds=[free_space.XWorldLimits; free_space.YWorldLimits; [-pi pi]];

j=1;
lengths=zeros(1,100); %array to hold lengths for each path
success=zeros(1,100); %array to hold if target is reached successfully
tic
while j<101
    qf=qgoal(:,j);
    planner=plannerRRT(ss,sv);
    planner.MaxConnectionDistance=0.3;
    [pthObj,solnInfo]=plan(planner,q0',qf');
    if length(path)>0
        L=0;
        for i=1:length(path)-1
            L=L+norm(path(i+1,:)-path(i,:));
        end
        lengths(j)=L;
        success(j)=1;
    end
    j=j+1;
end
toc
sum(success)
sum(lengths)

%figure(1); hold on
%plot(solnInfo.TreeData(:,1), solnInfo.TreeData(:,2),'.-');

%plot(pthObj.States(:,1), pthObj.States(:,2),'r-','Linewidth',2)

