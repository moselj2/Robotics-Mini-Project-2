addpath(genpath(pwd))
close all;

rw=0.2; rz=0.1;
robot=collisionCylinder(rw, rz);
colobj = roomspec();
roomshow(colobj, 1);
axis('square');

%Run "point_generator" to create random points across map

q0=[1;2;0];
q(:,1)=q0;


N_step=500;
right=0;
left=0;
max_dq=[0.1;0.1;0.1]*1;
j=1;
lengths=zeros(1,100); %array to hold lengths for each path
success=zeros(1,100); %array to hold if target is reached successfully

while j<101
p_length=0;
qf=qgoal(:,j);
clear q;
q(:,1)=q0;
for k=1:N_step
    dq=0.2*(qf-q(:,k))/norm(qf-q(:,k)); %vector driving robot towards goal
    
    [isInt,dist,wp]=colcheck(robot,q(:,k),colobj); %find nearest obstacle
    [rho,loc]=min(dist);


    if (rho<0.6) && (right==left) %if approaching obstacle from free movement
        if (rand<0.5) %flip coin to see if clockwise or counter-clockwise
            right=1;
        else
            left=1;
        end
    end
    if right %move around object counter clockwise
        if leaveTest(robot,q(:,k),dq,colobj) %see if next straight move would collide (if not the robot can leave)
            right=0;
        else %if can't leave obstacle
            dq=skirtRight(q,robot,colobj,rho,wp{loc}(:,2),dq);
        end
    elseif left
        if leaveTest(robot,q(:,k),dq,colobj) %see if next straight move would collide (if not the robot can leave)
            left=0;
        else %if can't leave obstacle
            dq=skirtLeft(q,robot,colobj,rho,wp{loc}(:,2),dq);
        end
    end
    deltaq=max(abs(dq)>max_dq)*dq/max(abs(dq./max_dq))+~max(abs(dq)>max_dq)*dq;
    q(:,k+1)=q(:,k)+deltaq;
    p_length=p_length+norm(deltaq);

     % check collision 
    [isInt,dist,wp]=colcheck(robot,q(:,k+1),colobj);   
    if max(isnan(dist))>0
        %disp('collision!');
        break
    end

    %robotshow(robot,q(:,k+1));
    %pause(0.1);
    k=k+1;
    if (norm(qf(1:2)-q(1:2,end))<0.5)
        break
    end
end
roomshow(colobj, 1);
axis('square');
plot([q(1,:) qf(1)],[q(2,:) qf(2)]);
xlabel('X [meters]'); ylabel('Y [meters]');
lengths(j)=p_length;
success(j)=(norm(qf-q(:,k))<0.5);
j=j+1;
end
sum(success)
sum(lengths)


%robotshow(robot,qf);
%pause(1)
%close all;

%figure(2)
%roomshow(colobj, 1);
%axis('square');
%plot([q(1,:) qf(1)],[q(2,:) qf(2)]);
%xlabel('X [meters]'); ylabel('Y [meters]');


function dq=skirtRight(q,robot,colobj, rho,qf,dqprev)
    R=([0;0;1]*0.1/rho^2);
    dq=dqprev-hat([q(1:2,end)-qf(1:2);0])*R;
end

function dq=skirtLeft(q,robot,colobj, rho,qf,dqprev)
    R=([0;0;1]*0.1/rho^2);
    dq=dqprev+hat([q(1:2,end)-qf(1:2);0])*R;
end

function leave=leaveTest(robot,q,dq,colobj)
    [isInt,dist1,wp1]=colcheck(robot,q+dq,colobj);
    [isInt,dist2,wp2]=colcheck(robot,q+2*dq,colobj);
    [isInt,dist3,wp3]=colcheck(robot,q+3*dq,colobj);
    [isInt,dist4,wp4]=colcheck(robot,q+4*dq,colobj);
    [isInt,dist5,wp5]=colcheck(robot,q+5*dq,colobj);
    if (max(isnan(dist1))==0) && (max(isnan(dist2))==0) && (max(isnan(dist3))==0) &&...
        (max(isnan(dist4))==0) && (max(isnan(dist5))==0)
        leave=1;
    else
        leave=0;
    end
end