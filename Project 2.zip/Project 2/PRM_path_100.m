addpath(genpath(pwd))

colobj = roomspec();

resolution = 100;
binary_map = color2binary(colobj, resolution);

%show(binary_map);
%view(-90,90);

free_space=binary_map;
inflate(free_space,0.2);
show(free_space); view(-90,90);

q0=[.4;2;0];

%i=0;
%while i==0
%    qgoal=10*rand(2,1);
%    if checkOccupancy(free_space,qgoal(1:2)')==0
%        i=1;
%    end
%end
%qgoal=[8.5;6.9]

j=1;
lengths=zeros(1,100); %array to hold lengths for each path
success=zeros(1,100); %array to hold if target is reached successfully
tic
while j<101
    p_length=0;
    qf=qgoal(:,j);
    planner = mobileRobotPRM(free_space);
    %planner.NumNodes = 50;
    planner.NumNodes = 100;
    planner.ConnectionDistance = 2;
    path = findpath(planner,q0(1:2)',qf(1:2)');
    %show(planner); view(-90,90);
    if length(path)>0
        L=0;
        for i=1:length(path)-1
            L=L+norm(path(i+1,:)-path(i,:));
        end
        lengths(j)=L;
        success(j)=1;
    end
    j=j+1;
end
toc
sum(success)
sum(lengths)