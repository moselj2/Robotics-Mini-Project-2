addpath(genpath(pwd))
close all;

rw=0.2; rz=0.1;
robot=collisionCylinder(rw, rz);
colobj = roomspec();

roomshow(colobj, 1);
axis('square');

q0=[.4;2;0];
%%%%%%%%%%%%%%%%%%%%%%%%%%%% uncomment loop to generate random target
%resolution = 100;
%binary_map = color2binary(colobj, resolution);
%free_space=binary_map;
%inflate(free_space,0.2);
%i=0;
%while i==0    
%    qf=[10*rand(2,1) ;0]
%    if checkOccupancy(free_space,qf(1:2)')==0
%        i=1;
%    end
%end%%%%%%%%%%%%%%%%%%%%%%%%%%

%qf=[6;5.5;0]
%qf=[9;6;0]
%qf=[6;6;0]
q(:,1)=q0;

%gradient descent parameters
eta=0.001;
rho0=0.5;
Kp=diag([1;1;1])*0.06;
max_dq=[0.1;0.1;0.1]*5;

N_step=500;
j=1;
lengths=zeros(1,100); %array to hold lengths for each path
success=zeros(1,100); %array to hold if target is reached successfully

while j<101
p_length=0;
qf=qgoal(:,j);
clear q;
q(:,1)=q0;
for k=1:N_step
    dq=-(Kp*gradU_att(q(:,k),qf)'+gradU_rep(q(:,k),robot,colobj,rho0,eta)');
    deltaq=max(abs(dq)>max_dq)*dq/max(abs(dq./max_dq))+~max(abs(dq)>max_dq)*dq;
    if (k>5) && (norm(q(:,k-4)+q(:,k-3)+q(:,k-2)+q(:,k-1)+q(:,k)-5*q(:,k))<0.2) && (norm(qf-q(:,end))>0.5)
        %disp('escape!')
        deltaq=escape(q(:,k),robot,colobj);
    end
    q(:,k+1)=q(:,k)+deltaq;
    p_length=p_length+norm(deltaq);
     % check collision 
    [isInt,dist,wp]=colcheck(robot,q(:,k+1),colobj);   
    if max(isnan(dist))>0
        %disp('collision!');
        break
    end
    %robotshow(robot,q(:,k+1)); %uncomment two lines to show simulation
    %pause(0.1);
    k=k+1;
    if (norm(qf-q(:,k))<0.5)
        break
    end
end
roomshow(colobj, 1);
axis('square');
plot([q(1,:) qf(1)],[q(2,:) qf(2)]);
xlabel('X [meters]'); ylabel('Y [meters]');
lengths(j)=p_length;
success(j)=(norm(qf-q(:,k))<0.5);
j=j+1;
end
sum(success)
sum(lengths)
robotshow(robot,qf);
pause(1)
%close all;

%roomshow(colobj, 1);
%axis('square');
%plot([q(1,:) qf(1)],[q(2,:) qf(2)]);
%xlabel('X [meters]'); ylabel('Y [meters]');


function gradU=gradU_att(q,qf)
    gradU=(q-qf)';
end

function U=gradU_rep(q,robot,colobj,rho0,eta)
    [isInt,dist,wp]=colcheck(robot,q,colobj);
    [rho,loc]=min(dist);
    U=(rho<rho0)*(-eta/rho^2)*(1/rho-1/rho0)^2*(wp{loc}(:,1)-wp{loc}(:,2))';
end

function deltaq=escape(q,robot,colobj)
    [isInt,dist,wp]=colcheck(robot,q,colobj);
    [rho,loc]=sort(dist);
    grad1=(wp{loc(1)}(:,1)-wp{loc(1)}(:,2)); %vector from robot to nearest obstacle
    grad2=(wp{loc(2)}(:,1)-wp{loc(2)}(:,2)); %vector from robot to second nearest obstacle
    grad3=(wp{loc(3)}(:,1)-wp{loc(3)}(:,2)); %vector from robot to second nearest obstacle
    grad=(grad1+grad2+0.75*grad3)/norm(grad1+grad2+0.75*grad3); %combine vectors and normalize
    gradR=[grad(1:2)+(rand(2,1)+[-0.5;-0.5]) ; 0];
    deltaq=1.5*gradR;
end