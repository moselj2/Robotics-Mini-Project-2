clear all; close all;
colobj = roomspec();

resolution = 100;
binary_map = color2binary(colobj, resolution);
free_space=binary_map;
inflate(free_space,0.2);

i=1;
qgoal=zeros(3,100);
while i<101
    q=[10*rand(2,1) ;0];
    if checkOccupancy(free_space,q(1:2)')==0
        qgoal(:,i)=q;
        i=i+1;
    end
end

roomshow(colobj, 1);
axis('square');
scatter([qgoal(1,:)],[qgoal(2,:)]);
xlabel('X [meters]'); ylabel('Y [meters]');