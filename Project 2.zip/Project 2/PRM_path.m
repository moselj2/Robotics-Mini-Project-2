addpath(genpath(pwd))
clear all;

colobj = roomspec();

resolution = 100;
binary_map = color2binary(colobj, resolution);

%show(binary_map);
%view(-90,90);

free_space=binary_map;
inflate(free_space,0.2);
show(free_space); view(-90,90);

q0=[.55;2;0];

i=0;
while i==0
    qf=10*rand(2,1);
    if checkOccupancy(free_space,qf(1:2)')==0
        i=1;
    end
end
qf=[8.5;6.9]

planner = mobileRobotPRM(free_space);
planner.NumNodes = 50;
planner.ConnectionDistance = 2;

path = findpath(planner,q0(1:2)',qf(1:2)')
show(planner); view(-90,90);
%close all;
%show(free_space); view(-90,90); hold on; plot(path(:,1),path(:,2));
